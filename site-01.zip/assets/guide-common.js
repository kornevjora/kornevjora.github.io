(() => {
  const back = document.querySelector('[data-search-return]');
  if (back && document.referrer) {
    const previous = new URL(document.referrer);
    if (previous.origin === location.origin && previous.pathname === '/guides/') {
      const params = new URLSearchParams();
      for (const key of ['q','section','topic']) {
        const value = previous.searchParams.get(key);
        if (value) params.set(key,value.slice(0,120));
      }
      if (params.size) { back.href='/guides/?'+params; back.hidden=false; }
    }
  }
  const links = [...document.querySelectorAll('.sp-toc a')];
  const chapters = links.map(link => document.getElementById(link.hash.slice(1)));
  if (links.length && chapters.every(Boolean)) {
    let frame = 0;
    let current = -1;
    function updateChapter() {
      frame = 0;
      const threshold = Math.min(window.innerHeight * .3, 200);
      let next = 0;
      chapters.forEach((chapter,index) => { if (chapter.getBoundingClientRect().top <= threshold) next = index; });
      if (next === current) return;
      current = next;
      links.forEach((link,index) => {
        if (index === current) link.setAttribute('aria-current', 'location');
        else link.removeAttribute('aria-current');
      });
    }
    window.addEventListener('scroll', () => { if (!frame) frame = requestAnimationFrame(updateChapter); }, { passive: true });
    updateChapter();
  }
})();
