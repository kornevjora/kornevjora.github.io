(() => {
 document.querySelectorAll('[data-kit-demo]').forEach(demo=>{
 const form=demo.querySelector('[data-kit-form]'),name=demo.querySelector('[data-kit-name]'),email=demo.querySelector('[data-kit-email]'),copy=demo.querySelector('[data-kit-copy]'),mode=demo.querySelector('[data-kit-server]'),submit=demo.querySelector('[data-kit-submit]'),finish=demo.querySelector('[data-kit-finish]'),status=demo.querySelector('[data-kit-status]');let waiting=false,choice='ok';
 submit.disabled=false;status.textContent='Заполни форму вымышленными данными. Реального запроса не будет.';
 const valid=input=>input.value.trim()!==''&&input.validity.valid;
 const error=(input,bad)=>{input.setAttribute('aria-invalid',String(bad));document.getElementById(input.getAttribute('aria-describedby')).hidden=!bad;};
 [name,email].forEach(input=>input.addEventListener('input',()=>{if(input.getAttribute('aria-invalid')==='true'&&valid(input))error(input,false);}));
 const changed=()=>{if(!waiting)status.textContent='Данные или условный ответ изменены. Отправь форму ещё раз, чтобы увидеть новый результат.';};
 form.addEventListener('input',changed);mode.addEventListener('change',changed);
 form.addEventListener('submit',event=>{event.preventDefault();if(waiting)return;const wrong=[name,email].filter(input=>!valid(input));[name,email].forEach(input=>error(input,!valid(input)));if(wrong.length){status.textContent='Исправь отмеченные поля. Данные остаются в форме.';wrong[0].focus();return;}
 waiting=true;choice=mode.value;[name,email,copy,mode,submit].forEach(el=>el.disabled=true);submit.textContent='Отправляем…';form.setAttribute('aria-busy','true');finish.hidden=false;status.textContent='Имитируем ожидание. Нажми «Показать ответ сервера», чтобы продолжить.';finish.focus();});
 finish.addEventListener('click',()=>{if(!waiting)return;waiting=false;[name,email,copy,mode,submit].forEach(el=>el.disabled=false);submit.textContent='Оставить заявку';form.removeAttribute('aria-busy');finish.hidden=true;status.textContent=choice==='ok'?'Демонстрация: заявка получена. Запись ещё ждёт подтверждения. '+(copy.checked?'Копия заявки запрошена. ':'Копия заявки не запрошена. ')+'Реального запроса не было.':'Демонстрация: не удалось доставить заявку. Данные сохранены в полях; можно повторить. Реального запроса не было.';status.focus();});
 });

 document.querySelectorAll('[data-ppi-demo]').forEach(demo=>{
 const fields=['pw','ph','mw','mh','target'].map(k=>demo.querySelector('[data-ppi-'+k+']')),out=demo.querySelector('[data-ppi-result]'),chart=demo.querySelector('[data-ppi-chart]');
 const fmt=n=>n>0&&n<.01?'менее 0,01':new Intl.NumberFormat('ru-RU',{maximumFractionDigits:2}).format(n);
 const update=()=>{const [pw,ph,mw,mh,target]=fields.map(i=>i.value.trim()===''?NaN:Number(i.value));
 const invalid=[pw,ph,mw,mh,target].map((n,i)=>!Number.isFinite(n)||n<=0||n>1000000||(i<2&&!Number.isInteger(n))||(i>=2&&n<.01));
 fields.forEach((field,i)=>field.setAttribute('aria-invalid',String(invalid[i])));
 if(chart)chart.hidden=invalid.some(Boolean);
 if(invalid.some(Boolean)){const labels=fields.filter((_,i)=>invalid[i]).map(field=>field.closest('label').firstChild.textContent.trim());out.textContent='Проверь: '+labels.join('; ')+'. Пиксели — целые положительные числа, миллиметры и цель — не меньше 0,01. Верхняя граница каждого поля — 1 000 000.';return;}
 const ppi=Math.min(pw*25.4/mw,ph*25.4/mh),placedW=pw*25.4/ppi,placedH=ph*25.4/ppi;
 out.textContent='Эффективное разрешение: '+fmt(ppi)+' ppi. Цель '+fmt(target)+' ppi '+(ppi>=target?'достигнута.':'не достигнута.')+' Полное изображение размещено '+fmt(placedW)+' × '+fmt(placedH)+' мм; всё за пределами рамки обрезается. Для видимой области при этой цели нужно минимум '+Math.ceil(mw*target/25.4)+' × '+Math.ceil(mh*target/25.4)+' px.';
 if(chart){
   const scale=Math.min(300/pw,180/ph),sw=pw*scale,sh=ph*scale,sx=(360-sw)/2,sy=(240-sh)/2;
   const fw=sw*mw/placedW,fh=sh*mh/placedH,fx=(360-fw)/2,fy=(240-fh)/2;
   const rect=(selector,x,y,w,h)=>{const el=chart.querySelector(selector);Object.entries({x,y,width:w,height:h}).forEach(([key,value])=>el.setAttribute(key,value));};
   rect('[data-ppi-source-border]',sx,sy,sw,sh);rect('[data-ppi-frame]',fx,fy,fw,fh);rect('[data-ppi-clip]',fx,fy,fw,fh);
   chart.querySelectorAll('[data-ppi-source-art],[data-ppi-visible-art]').forEach(el=>el.setAttribute('transform',`translate(${sx} ${sy}) scale(${sw/300} ${sh/200})`));
   const visible=Math.min(100,(mw*mh)/(placedW*placedH)*100),crop=Math.max(0,100-visible);
   const caption=crop<1e-8?'Пропорции совпадают: исходник виден целиком.':crop<.01?'Пропорции почти совпадают: обрезается менее 0,01% площади исходника.':`В рамке видно ${fmt(visible)}% площади исходника. ${fmt(crop)}% остаётся за рамкой и обрезается. Кадрирование — по центру.`;
   chart.querySelector('[data-ppi-crop-caption]').textContent=caption;
   chart.querySelector('[data-ppi-svg]').setAttribute('aria-label',`Исходник ${pw} × ${ph} px, область ${fmt(mw)} × ${fmt(mh)} мм. ${caption}`);
   chart.querySelector('[data-ppi-summary]').textContent=fmt(ppi)+' / '+fmt(target)+' ppi';
   const badge=chart.querySelector('[data-ppi-badge]');badge.textContent=ppi>=target?'Цель достигнута':'Ниже цели';badge.dataset.state=ppi>=target?'good':'low';
 }
 };fields.forEach(i=>i.addEventListener('input',update));
 demo.querySelectorAll('[data-ppi-preset]').forEach(button=>button.addEventListener('click',()=>{const values=button.dataset.ppiPreset==='square'?[1536,1024,200,200,300]:[1536,1024,120,80,300];fields.forEach((field,i)=>field.value=values[i]);update();}));update();
 });

  document.querySelectorAll('[data-rate-demo]').forEach(demo=>{
    const inputs=['at','as','bt','bs'].map(key=>demo.querySelector('[data-rate-'+key+']')),out=demo.querySelector('[data-rate-result]'),chart=demo.querySelector('[data-rate-chart]');
    const number=n=>new Intl.NumberFormat('ru-RU',{maximumFractionDigits:2}).format(n);
    const update=()=>{
      const values=inputs.map(i=>i.value.trim()===''?NaN:Number(i.value)),[at,as,bt,bs]=values;
      const invalid=values.map(n=>!Number.isSafeInteger(n)||n<0);if(as>at)invalid[1]=true;if(bs>bt)invalid[3]=true;
      inputs.forEach((input,i)=>input.setAttribute('aria-invalid',String(invalid[i]||((i===0||i===2)&&values[i]===0))));
      if(chart)chart.hidden=invalid.some(Boolean)||!at||!bt;
      if(invalid.some(Boolean)){const labels=inputs.filter((_,i)=>invalid[i]).map(input=>input.closest('label').firstChild.textContent.trim());out.textContent='Проверь: '+labels.join('; ')+'. Нужны целые неотрицательные количества. Число выполнивших не может превышать число начавших. Слишком большие числа также не принимаются.';return;}
      if(!at||!bt){out.textContent='При нулевом числе начавших доля этой группы не определена. Для сравнения нужны ненулевые знаменатели.';return;}
      const a=as/at*100,b=bs/bt*100,d=b-a,relative=a===0?'не определено: исходная доля A равна нулю':number(d/a*100)+'%';
      out.textContent='A: '+number(a)+'%. B: '+number(b)+'%. Разница: '+number(d)+' процентных пунктов. Относительное изменение: '+relative+'.';
      if(chart)for(const [group,success,total,rate] of [['a',as,at,a],['b',bs,bt,b]]){chart.querySelector('[data-rate-bar-'+group+']').style.width=rate+'%';chart.querySelector('[data-rate-caption-'+group+']').textContent=number(success)+' из '+number(total)+' · '+number(rate)+'%';}
    };inputs.forEach(i=>i.addEventListener('input',update));
    demo.querySelectorAll('[data-rate-preset]').forEach(button=>button.addEventListener('click',()=>{const values={growth:[200,40,200,50],equal:[200,40,100,20],zero:[200,0,200,50]}[button.dataset.ratePreset];inputs.forEach((input,i)=>input.value=values[i]);update();}));update();
  });

  document.querySelectorAll('[data-form-transfer]').forEach(demo=>{
    const form=demo.querySelector('[data-transfer-form]'),status=demo.querySelector('[data-transfer-status]'),result=demo.querySelector('[data-transfer-result]');
    const fields=[...form.querySelectorAll('input,textarea')];
    const valid=input=>input.value.trim()!==''&&input.validity.valid;
    const mark=(input,bad)=>{input.setAttribute('aria-invalid',String(bad));const error=demo.querySelector('#'+input.getAttribute('aria-describedby'));if(error)error.hidden=!bad;};
    const invalidate=()=>{result.hidden=true;status.textContent='Данные или подключение изменены. Нажми «Проверить передачу в примере», чтобы получить новый результат.';};
    form.addEventListener('input',invalidate);form.querySelector('select').addEventListener('change',invalidate);
    fields.forEach(input=>input.addEventListener('input',()=>{if(valid(input))mark(input,false);}));
    demo.querySelector('[data-transfer-submit]').disabled=false;
    form.addEventListener('submit',event=>{
      event.preventDefault();
      const wrong=fields.filter(input=>!valid(input));fields.forEach(input=>mark(input,!valid(input)));
      if(wrong.length){result.hidden=true;status.textContent='Исправь отмеченные поля. Это локальный пример; данные никуда не отправлены.';wrong[0].focus();return;}
      const values=new FormData(form),name=String(values.get('demo_name')).trim(),email=String(values.get('demo_email')).trim(),comment=String(values.get('demo_comment')).trim(),mode=values.get('demo_mode');
      if(!name||!email||!comment){demo.querySelector('[data-transfer-result]').hidden=true;status.textContent='Заполните имя, email и комментарий вымышленными значениями.';return;}
      const record='name: '+name+'\nemail: '+email+'\ncomment: '+comment;
      demo.querySelector('[data-transfer-input]').textContent=record;
      demo.querySelector('[data-transfer-output]').textContent=mode==='ok'?record:mode==='unselected'?'Строки нет: приёмник не назначен этой форме.':'Строки нет в условиях примера: приёмник сообщил об ошибке доставки.';
      demo.querySelector('[data-transfer-result]').hidden=false;
      status.textContent=mode==='ok'?'В этой демонстрации поля переданы без изменений. Во внешних сервисах ничего не создано.':mode==='unselected'?'Следующая проверка: Connected Services у конкретной формы и публикация страницы.':'Следующая проверка: запись в Leads → Errors log, текст ошибки и состояние нужного приёмника.';
    });
  });

  document.querySelectorAll('[data-prototype-demo]').forEach(demo=>{
    let current='list',history=[];
    const status=demo.querySelector('[data-proto-status]'),check=demo.querySelector('[data-proto-action="check"]');
    const render=(message,focus=false)=>{demo.querySelectorAll('[data-proto-screen]').forEach(panel=>panel.hidden=panel.dataset.protoScreen!==current);status.textContent=message;if(focus)demo.querySelector('[data-proto-screen="'+current+'"] [data-proto-title]').focus({preventScroll:true});};
    const resetCheck=()=>{check.setAttribute('aria-checked','false');demo.querySelector('[data-proto-mark]').textContent='□';};
    demo.querySelector('[data-proto-controls]').hidden=false;
    demo.querySelectorAll('[data-proto-start]').forEach(button=>button.addEventListener('click',()=>{current=button.dataset.protoStart;history=[];resetCheck();render(current==='list'?'Старт: List. Нажатие карточки откроет Detail.':'Старт: Detail. История пуста: Back не имеет предыдущего экрана.',true);}));
    demo.querySelectorAll('[data-proto-action]').forEach(button=>button.addEventListener('click',()=>{
      const action=button.dataset.protoAction;
      if(action==='check'){const checked=check.getAttribute('aria-checked')!=='true';check.setAttribute('aria-checked',String(checked));demo.querySelector('[data-proto-mark]').textContent=checked?'☑':'□';status.textContent='Change to → State='+(checked?'On':'Off')+'. Экран Detail остаётся открытым.';return;}
      if(action==='back'){if(!history.length){status.textContent='Back: предыдущего экрана нет. Начните со списка или используйте «Все занятия».';return;}current=history.pop();render('Back: возврат на предыдущий экран '+(current==='list'?'List':'Detail')+'.',true);return;}
      history.push(current);current=action;render('Navigate to → '+(current==='list'?'List':'Detail')+'. Выбрана явная цель перехода.',true);
    }));
    render('Старт: List. Нажатие карточки откроет Detail.');
  });


  document.querySelectorAll('[data-responsive-demo]').forEach(demo=>{
    const frame=demo.querySelector('[data-responsive-frame]'),measure=demo.querySelector('[data-responsive-measure]');
    if(!frame||!measure)return;
    const update=()=>{const style=getComputedStyle(demo),room=demo.clientWidth-parseFloat(style.paddingLeft)-parseFloat(style.paddingRight);measure.textContent='Фактическая ширина рамки: '+Math.round(frame.getBoundingClientRect().width)+' px. '+(room<=320?'Здесь уже доступно не больше 320 px, поэтому оба режима показывают одну колонку. Разницу ширины можно увидеть в более широком окне.':'Размер ограничен доступным местом в гайде.');};
    demo.querySelectorAll('[data-responsive-size]').forEach(button=>button.addEventListener('click',()=>{frame.classList.toggle('is-narrow',button.dataset.responsiveSize==='narrow');demo.querySelectorAll('[data-responsive-size]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));update();}));
    if('ResizeObserver' in window)new ResizeObserver(update).observe(frame);update();
  });


  document.querySelectorAll('[data-clip-demo]').forEach(demo=>{
    const messages={clipped:'Высота карточки фиксирована, содержимое за её границей скрыто. Часть текста и кнопка недоступны визуально.',overlap:'Обрезка убрана, но карточка не выросла, а кнопка осталась на прежней позиции. Текст выходит за границу и сталкивается с кнопкой.',flow:'Карточка растёт по содержимому. Кнопка следует за абзацем с сохранённым отступом. Весь текст виден без уменьшения шрифта.'};
    demo.querySelectorAll('[data-clip-choice]').forEach(button=>button.addEventListener('click',()=>{const mode=button.dataset.clipChoice;if(!messages[mode])return;demo.dataset.mode=mode;demo.querySelectorAll('[data-clip-choice]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));demo.querySelector('[data-clip-message]').textContent=messages[mode];}));
  });


  document.querySelectorAll('[data-route-demo]').forEach(demo=>{
    const origin=demo.querySelector('[data-route-origin]'),link=demo.querySelector('[data-route-link]'),result=demo.querySelector('[data-route-result]'),explanation=demo.querySelector('[data-route-explanation]');
    if(!origin||!link||!result||!explanation)return;
    const update=()=>{const url=new URL(link.value,'https://example.org'+origin.value);result.textContent=url.pathname+url.hash;explanation.textContent=url.hash?(url.pathname==='/'?'Якорь ищется на главной странице. В нашем примере раздел classes на ней есть.':'Якорь ищется внутри статьи /journal. В нашем примере такого раздела в статье нет: переход к занятиям не состоится.'):'Открывается отдельная страница /about. Якорь в этой ссылке не задан.';};
    origin.addEventListener('change',update);link.addEventListener('change',update);update();
  });
  document.querySelectorAll('[data-cart-demo]').forEach(demo=>{
    const volume=demo.querySelector('[data-cart-volume]'),quantity=demo.querySelector('[data-cart-quantity]'),wrap=demo.querySelector('[data-cart-wrap]'),delivery=demo.querySelector('[data-cart-delivery]');
    if(!volume||!quantity||!wrap||!delivery)return;
    const money=n=>new Intl.NumberFormat('ru-RU').format(n)+' ₽';
    const update=()=>{const price=volume.value==='250'?1600:1900,n=Number(quantity.value),extra=Number(wrap.value),shipping=Number(delivery.value),products=(price+extra)*n,total=products+shipping;
      demo.querySelector('[data-cart-products]').textContent=money(products);
      demo.querySelector('[data-cart-shipping]').textContent=money(shipping);
      demo.querySelector('[data-cart-total]').textContent=money(total);
      demo.querySelector('[data-cart-formula]').textContent='('+new Intl.NumberFormat('ru-RU').format(price)+' + '+extra+') × '+n+' + '+shipping+' = '+money(total);
      demo.querySelector('[data-cart-fields]').textContent=shipping?'Для курьера нужен адрес доставки. Способ получения и адрес должны попасть в заказ.':'Для самовывоза нужен выбранный пункт получения. Домашний адрес покупателя не требуется.';
      demo.querySelector('[data-cart-payload]').textContent='Товар: Туман · '+volume.value+' мл\nАртикул: TUM-'+volume.value+'\nКоличество: '+n+'\nУпаковка: '+(extra?money(extra)+' / шт.':'нет')+'\nПолучение: '+(shipping?'курьер':'самовывоз')+'\nДоставка: '+money(shipping)+'\nИтого: '+money(total);
    };
    [volume,quantity,wrap,delivery].forEach(el=>el.addEventListener('change',update));update();
  });

  document.querySelectorAll('[data-length-demo]').forEach(demo=>{
    const input=demo.querySelector('[data-length-input]'),total=demo.querySelector('[data-length-total]'),status=demo.querySelector('[data-length-status]');
    if(!input||!total||!status)return;
    const min=Number(demo.dataset.min),max=Number(demo.dataset.max);
    const update=()=>{const n=Array.from(input.value.replace(/\r\n?/g,'\n')).length;total.textContent=n;status.textContent=n<min?'До нижней границы не хватает '+(min-n)+' знаков. Добавляй подтверждённые сведения, а не повторы.':n>max?'Верхняя граница превышена на '+(n-max)+' знаков. Сократи текст, сохранив обязательные условия.':'Текст в диапазоне. До верхней границы осталось '+(max-n)+' знаков. Смысл и факты проверяются отдельно.';};
    input.addEventListener('input',update);
    demo.querySelectorAll('[data-length-preset]').forEach(button=>button.addEventListener('click',()=>{const preset=demo.querySelector('template[data-length-value="'+button.dataset.lengthPreset+'"]');if(preset){input.value=preset.content.textContent;update();}}));
    update();
  });
  document.querySelectorAll('[data-hover-demo]').forEach(demo => {
    const toggle=demo.querySelector('[data-hover-toggle]');
    toggle?.addEventListener('click',()=>{ const on=demo.classList.toggle('is-hovered'); toggle.setAttribute('aria-pressed',String(on)); });
  });
  document.querySelectorAll('[data-appearance-demo]').forEach(demo => {
    demo.querySelector('[data-appearance-replay]')?.addEventListener('click',()=>{demo.classList.remove('fg-replay');void demo.offsetWidth;demo.classList.add('fg-replay');});
  });
  document.querySelectorAll('[data-layer-demo]').forEach(demo => {
    const cover=demo.querySelector('[data-layer-cover]'),toggle=demo.querySelector('[data-layer-toggle]'),target=demo.querySelector('[data-layer-target]'),out=demo.querySelector('[data-layer-output]');
    if(!cover||!toggle||!target||!out)return;
    toggle.addEventListener('click',()=>{cover.hidden=!cover.hidden;toggle.setAttribute('aria-pressed',String(cover.hidden));toggle.textContent=cover.hidden?'Вернуть перекрывающий слой':'Убрать перекрывающий слой';out.textContent=cover.hidden?'Слой убран. Нажатие указателем достигает кнопки.':'Слой снова перекрывает кнопку. Он подсвечен только для объяснения.';});
    cover.addEventListener('click',()=>{out.textContent='Нажатие получил верхний слой. До кнопки оно не дошло.';});
    target.addEventListener('click',()=>{out.textContent='Кнопка получила нажатие. Это демонстрация: данные никуда не отправляются.';});
  });
  document.querySelectorAll('[data-theme-demo]').forEach(demo => {
    const controls = demo.querySelector('[data-theme-controls]');
    const canvas = demo.querySelector('[data-color-theme]');
    const buttons = [...demo.querySelectorAll('[data-color-choice]')];
    if (!controls || !canvas || !buttons.length) return;
    controls.hidden = false;
    buttons.forEach(button => button.addEventListener('click', () => {
      const theme = button.dataset.colorChoice;
      if (!['light', 'dark'].includes(theme)) return;
      canvas.dataset.colorTheme = theme;
      buttons.forEach(item => item.setAttribute('aria-pressed', String(item === button)));
    }));
  });
  document.querySelectorAll('[data-state-demo]').forEach(demo => {
    const controls = demo.querySelector('[data-state-controls]');
    const buttons = [...demo.querySelectorAll('[data-state-choice]')];
    const panels = [...demo.querySelectorAll('[data-state-panel]')];
    const announcement = demo.querySelector('[data-state-announcement]');
    if (!controls || !buttons.length || !panels.length) return;
    const show = (button, announce) => {
      const selected = panels.find(panel => panel.dataset.statePanel === button.dataset.stateChoice);
      if (!selected) return;
      panels.forEach(panel => { panel.hidden = panel !== selected; });
      buttons.forEach(item => item.setAttribute('aria-pressed', String(item === button)));
      if (announce && announcement) announcement.textContent = `Показан пример: ${button.textContent.trim()}`;
    };
    controls.hidden = false;
    show(buttons[0], false);
    buttons.forEach(button => button.addEventListener('click', () => show(button, true)));
  });
  document.querySelectorAll('[data-view-demo]').forEach(demo => {
    const controls = demo.querySelector('[data-demo-controls]');
    const buttons = [...demo.querySelectorAll('[data-view-choice]')];
    if (!controls || !buttons.length) return;
    controls.hidden = false;
    const describe=()=>{const status=demo.querySelector('[data-view-status]');if(status)status.textContent=window.matchMedia('(max-width:600px)').matches?'На этом узком экране сетка уже стала одной колонкой. Оба режима сохраняют читаемый текст; разницу раскладки можно увидеть в широком окне.':demo.dataset.view==='narrow'?'Показана одна колонка шириной до 280 px. Сравни высоту карточек до и после.':'Показана сетка из трёх колонок. Сравни высоту карточек и положение действий.';};
    buttons.forEach(button => button.addEventListener('click', () => {
      const view = button.dataset.viewChoice;
      if (!['wide', 'narrow'].includes(view)) return;
      demo.dataset.view = view;
      buttons.forEach(item => item.setAttribute('aria-pressed', String(item === button)));
      describe();
    }));
    window.addEventListener('resize',describe,{passive:true});describe();
  });
})();
