document.querySelectorAll('[data-copy]').forEach(button=>{
  button.addEventListener('click',async()=>{
    const input=document.getElementById(button.dataset.copy);
    const status=button.closest('.course-prompt').querySelector('.copy-status');
    try {
      if(!navigator.clipboard?.writeText)throw new Error('Clipboard unavailable');
      await navigator.clipboard.writeText(input.value);
      status.textContent='Скопировано. Вставь текст в чат.';
    } catch {
      input.focus();input.select();
      status.textContent='Текст выделен. Нажми Ctrl+C или выбери «Копировать» в меню устройства.';
    }
  });
});
