export const normalize = value => String(value||'').toLocaleLowerCase('ru').replaceAll('ё','е').normalize('NFKC');
const stopWords=new Set('как что где почему зачем мне нужно нужен нужна нужны хочу сделать делать подскажите помоги гайд гайды про по для на в во к из и или с со у о об это так же ли а бы быть его ее свой свои'.split(' '));
const aliases=[
  [/^(figma|фигма|фигме|фигму|фигмы|фигмой|фиг)$/,'figma'],
  [/^(tilda|тильда|тильде|тильду|тильды|тильдой)$/,'tilda'],
  [/^(pdf|пдф)$/,'pdf'],[/^(png|пнг)$/,'png'],
  [/^(ии|ai|нейросет.*|нейронк.*|chatgpt|чатгпт|gpt)$/,'ии'],
  [/^(ux|юикс)$/,'ux'],[/^(ui|юай)$/,'ui'],
  [/^(автолейаут|автолэйаут|autolayout)$/,'autolayout'],
  [/^аргумент|^обоснов/,'обоснование'],
  [/^пиксел/,'пиксель'],[/^отступ/,'отступ'],
  [/^отправ/,'отправка'],[/^экспорт/,'экспорт'],
];
function stem(word) {
  if(word.length<5||!/[а-я]/.test(word))return word;
  return word.replace(/(иями|ями|ами|ого|ему|ому|ыми|ими|иях|ием|ах|ях|ый|ий|ая|ое|ые|ой|ую|ей|ия|ие|ию|ии|ся|ть|ти|ет|ют|ит|ат|ят|ем|ом|ов|ев|а|я|ы|и|е|у|ю|о|ь)$/,'');
}
function canonical(word){return stem(aliases.find(([pattern])=>pattern.test(word))?.[1]||word);}
function terms(value) {
  const words=(normalize(value).replace(/auto\s+layout/g,'autolayout').match(/[\p{L}\p{N}]+/gu)||[]).filter(w=>!stopWords.has(w));
  return [...new Set(words.map(canonical))];
}
export function indexGuide(item) {
  return {...item,phrase:normalize(item.title),fields:[item.title+' '+(item.aliases||''),item.topic,item.description,item.keywords].map(value=>terms(value))};
}
function near(a,b){
  if(Math.abs(a.length-b.length)>1||Math.min(a.length,b.length)<5)return false;
  if(a.length===b.length){const different=[];for(let i=0;i<a.length;i++)if(a[i]!==b[i])different.push(i);return different.length===1||(different.length===2&&different[1]===different[0]+1&&a[different[0]]===b[different[1]]&&a[different[1]]===b[different[0]]);}
  if(a.length>b.length)[a,b]=[b,a];
  let i=0,j=0,skipped=false;while(i<a.length&&j<b.length){if(a[i]===b[j]){i++;j++;}else{if(skipped)return false;skipped=true;j++;}}return true;
}
function tokenScore(query,word,fuzzy){
  if(query===word)return 1;
  if(Math.min(query.length,word.length)>=3&&(word.startsWith(query)||query.startsWith(word)))return .8;
  return fuzzy && near(query,word) ? .6 : 0;
}
function rank(items,query,allowFuzzy){
  const weights=[16,8,4,2],phrase=normalize(query),tokens=terms(query);
  if(!tokens.length)return items.map(item=>({item,score:0}));
  return items.map(item=>{
    const matches=tokens.map(token=>Math.max(...item.fields.map((field,i)=>Math.max(0,...field.map(word=>tokenScore(token,word,allowFuzzy)))*weights[i])));
    const score=matches.every(Boolean)?matches.reduce((a,b)=>a+b,0)+(item.phrase===phrase?100:item.phrase.includes(phrase)?32:0):0;
    return {item,score};
  }).filter(x=>x.score>0).sort((a,b)=>b.score-a.score||a.item.order-b.item.order);
}
export function searchGuides(items,query){
  const exact=rank(items,query,false);
  return exact.length?{matches:exact,fuzzy:false}:{matches:rank(items,query,true),fuzzy:true};
}
