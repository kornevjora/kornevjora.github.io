import { indexGuide, searchGuides } from './search-engine.js?v=68ffb49634';

const form = document.querySelector('.catalog-form');
const query = document.querySelector('#search');
const section = document.querySelector('#section');
const topic = document.querySelector('#topic');
const summary = document.querySelector('[data-results]');
const emptyState = document.querySelector('[data-empty]');
const reset = document.querySelector('[data-clear-search]');
const clearQuery = document.querySelector('[data-clear-query]');
const expandSearch = document.querySelector('[data-expand-search]');
const groups = [...document.querySelectorAll('[data-topic-group]')];
const index = [...document.querySelectorAll('[data-guide]')].map((card,order)=>indexGuide({
  card,order,section:card.dataset.section,topicKey:card.dataset.topic,
  title:card.dataset.title,aliases:card.dataset.aliases,topic:card.dataset.topicName,description:card.dataset.description,keywords:card.dataset.keywords,
}));
const topicOptions = [...topic.querySelectorAll('option[data-section]')];
const countLabel = n => n+' '+(n%10===1&&n%100!==11?'гайд':n%10>=2&&n%10<=4&&(n%100<12||n%100>14)?'гайда':'гайдов');

function syncTopics() {
  for (const option of topicOptions) {
    option.hidden = !!section.value && option.dataset.section!==section.value;
    option.disabled = option.hidden;
  }
  topic.querySelectorAll('optgroup').forEach(group=>{
    group.hidden=!!section.value&&group.dataset.sectionOptions!==section.value;
    group.disabled=group.hidden;
  });
  if (topic.selectedOptions[0]?.disabled) topic.value='';
}

function syncInputs() {
  const params = new URLSearchParams(location.search);
  query.value=(params.get('q')||'').slice(0,120);
  section.value=['design','ai'].includes(params.get('section'))?params.get('section'):'';
  const selected=topicOptions.find(option=>option.value===params.get('topic'));
  topic.value=selected?.value||'';
  if (selected) section.value=selected.dataset.section;
  syncTopics();
}

function filterGuides() {
  const scoped = index.filter(item=>(!section.value||item.section===section.value)&&(!topic.value||item.topicKey===topic.value));
  const result = searchGuides(scoped,query.value.trim());
  const scores = new Map(result.matches.map(({item,score})=>[item.card,score]));
  index.forEach(item=>{item.card.hidden=!scores.has(item.card);});
  const rankedGroups=groups.map((group,order)=>{
    const items=index.filter(item=>item.topicKey===group.dataset.topic);
    const visible=items.filter(item=>scores.has(item.card));
    group.hidden=visible.length===0;
    group.querySelector('[data-topic-count]').textContent=countLabel(visible.length);
    // DOM order follows relevance for keyboard and screen-reader users too.
    const grid=group.querySelector('.guide-grid');
    items.sort((a,b)=>(scores.get(b.card)||0)-(scores.get(a.card)||0)||a.order-b.order).forEach(item=>grid.append(item.card));
    return {group,order,score:Math.max(0,...visible.map(item=>scores.get(item.card)))};
  });
  const container=document.querySelector('[data-topic-groups]');
  rankedGroups.sort((a,b)=>b.score-a.score||a.order-b.order).forEach(({group})=>container.append(group));
  const count=result.matches.length;
  const scope=topic.value?' · '+topic.selectedOptions[0].textContent:section.value?' · '+section.selectedOptions[0].textContent:'';
  summary.textContent=count===0?'Ничего не найдено'+scope:result.fuzzy?'Точных совпадений нет. Похожие материалы: '+count+scope:query.value.trim()?'Найдено: '+countLabel(count)+scope:countLabel(count)+scope;
  emptyState.hidden=count>0;
  reset.hidden=!(query.value||section.value||topic.value);
  clearQuery.hidden=!query.value;
  expandSearch.hidden=true;
  if (!count&&(section.value||topic.value)&&query.value.trim()) {
    const total=searchGuides(index,query.value.trim()).matches.length;
    if (total) {
      expandSearch.hidden=false;
      expandSearch.href='/guides/?'+new URLSearchParams({q:query.value.trim()});
      expandSearch.textContent='Искать во всех разделах · '+countLabel(total);
    }
  }
}

function updateResults() {
  const params=new URLSearchParams();
  if(query.value.trim())params.set('q',query.value.trim());
  if(section.value)params.set('section',section.value);
  if(topic.value)params.set('topic',topic.value);
  history.replaceState(null,'',location.pathname+(params.size?'?'+params:''));
  filterGuides();
}

query.addEventListener('input',updateResults);
section.addEventListener('change',()=>{syncTopics();updateResults();});
topic.addEventListener('change',()=>{
  if(topic.value)section.value=topic.selectedOptions[0].dataset.section;
  syncTopics();updateResults();
});
form.addEventListener('submit',event=>{
  event.preventDefault();updateResults();
  summary.focus({preventScroll:true});summary.scrollIntoView({block:'start'});
});
clearQuery.addEventListener('click',()=>{query.value='';updateResults();query.focus();});
window.addEventListener('popstate',()=>{syncInputs();filterGuides();});
window.addEventListener('pageshow',event=>{if(event.persisted){syncInputs();filterGuides();}});
syncInputs();filterGuides();
if(location.hash==='#search')query.focus({preventScroll:true});
