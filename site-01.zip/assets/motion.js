(() => {
  const motion = window.matchMedia('(prefers-reduced-motion: no-preference)');
  if (!motion.matches) return;

  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      for (const { target, isIntersecting } of entries) {
        if (!isIntersecting) continue;
        observer.unobserve(target);
        if (!motion.matches || typeof target.animate !== 'function') continue;
        target.animate(
          [{ opacity: .38, transform: 'translateY(13px)' }, { opacity: 1, transform: 'translateY(0)' }],
          { duration: 470, easing: 'cubic-bezier(.2,.7,.23,1)' },
        );
      }
    }, { threshold: .15 });
    document.querySelectorAll('[data-reveal]').forEach((element) => observer.observe(element));
  }

  const stage = document.querySelector('[data-hero-motion]');
  const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)');
  if (!stage || !finePointer.matches) return;

  let frame = 0;
  stage.addEventListener('pointermove', (event) => {
    if (!motion.matches || event.pointerType !== 'mouse') return;
    cancelAnimationFrame(frame);
    frame = requestAnimationFrame(() => {
      const bounds = stage.getBoundingClientRect();
      const x = (event.clientX - bounds.left) / bounds.width - .5;
      const y = (event.clientY - bounds.top) / bounds.height - .5;
      stage.style.setProperty('--scene-x', (x * 22).toFixed(1) + 'px');
      stage.style.setProperty('--scene-y', (y * 18).toFixed(1) + 'px');
    });
  }, { passive: true });
  stage.addEventListener('pointerleave', () => {
    cancelAnimationFrame(frame);
    stage.style.removeProperty('--scene-x');
    stage.style.removeProperty('--scene-y');
  });
})();
